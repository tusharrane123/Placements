package jan22;

public class UpperCase_AtoZ {

	public static void main(String[] args) {
		char c = 'A';
		while(c <= 'Z'){
			System.out.println(c+" ");
			c++;
		}
	}
}
